package com.example.certificate.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.certificate.model.Certificate;
import com.example.certificate.model.Employee;
import com.example.certificate.repository.IEmployeeRepo;
import com.example.certificate.service.EmployeeService;

@Controller
public class CertificateController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private IEmployeeRepo iemployeerepo;
	
	@PostMapping("/create")
	public String Create() {
		
		Certificate c = new Certificate("JAVA","17/04/2017","27/05/2017","completed");
		List l = new ArrayList<>();
		l.add(c);
		Employee e = new Employee("4003","SHREYA PAWAR","12345","USER",l);
		return employeeService.create(e).toString();
	}
	
	@GetMapping("/get")
	public String get(){
		return employeeService.getAll().toString();
	
	}
	
	@RequestMapping ("/")
	public String welcome(@ModelAttribute ("t") Employee e)
	{
		return "welcome";
	}
	@RequestMapping(value="/index",method= RequestMethod.POST)
	public String checkLogin(@ModelAttribute("t") Employee e,ModelMap m)
	{
		Employee em = iemployeerepo.findById(e.getEmplId()).get();
		if(e.getPassword().equals(em.getPassword()))
		{
			if(em.getRole().equals("ADMIN"))
			{
				List<Employee> l = (List<Employee>) iemployeerepo.findAll();
				System.out.println(l.remove(0));
				m.addAttribute("admin",em);
				m.addAttribute("l",l);
				
				System.out.println("admin part:"+l);
				return "admin";
			}
			else
			{
				m.addAttribute("emp",em);
				System.out.println("user part:"+em);
				return "user";
			}
		}
		else 
			return "welcome";
	}
	
	@RequestMapping(value="/cert/{id}",method =RequestMethod.GET)
	public String getCertificates(@PathVariable("id") String id,ModelMap m) {
		Employee e=employeeService.findById(id);
        m.addAttribute("emp",e);
		return "certificates";
	}
	
	@RequestMapping(value="/addCert/{id}",method =RequestMethod.GET)
	public String getCertificates(@PathVariable("id") String id,@ModelAttribute("t") Certificate c,ModelMap m) {
		m.addAttribute("empid",id);
		return "addCertificate";
	}
	

	@RequestMapping(value="/cert/{id}",method =RequestMethod.POST)
	public String updateCertificatesList(@PathVariable("id") String id,@ModelAttribute("t") Certificate c,ModelMap m) {
		System.out.println("certificate to add: "+c);
		Employee e=employeeService.Update(id, c);
		System.out.println( "Update:  "+e);
		m.addAttribute("emp",  e);
		return "certificates";
	}
	
	
}
